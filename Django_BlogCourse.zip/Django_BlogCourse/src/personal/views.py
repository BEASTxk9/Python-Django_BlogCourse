from django.shortcuts import render

# Create your views here.

# create function
def landing_view(request):
    print(request.headers)
    return render(request, "base.html", {})

# create function
def home_view(request):
    print(request.headers)
    return render(request, "personal/home.html", {})

