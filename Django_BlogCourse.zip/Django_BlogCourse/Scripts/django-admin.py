#!C:\Users\shanes\Desktop\WORK\Python_website\Django_BlogCourse\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
